<?php
// Making config for database connection reuse through include_once
$serverName = "localhost";
$dBUsername = "root";
$dBPassword = "root";  // Ensure this is the correct password
$dBName = "electric-shop";

// Create connection
$conn = new mysqli($serverName, $dBUsername, $dBPassword, $dBName);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
